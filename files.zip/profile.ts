import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Game } from '../../models/game';
import { WishlistService } from '../../services/wishlist.service';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './profile.html',
})
export class ProfileComponent implements OnInit {
  private wishlistService = inject(WishlistService);
  private profileService = inject(ProfileService); // ya existente, sin tocar su lógica

  favorites: Game[] = [];
  loading = true;
  errorMessage: string | null = null;

  ngOnInit(): void {
    this.loadFavorites();
  }

  private loadFavorites(): void {
    this.loading = true;
    this.errorMessage = null;

    this.wishlistService.getWishlist().subscribe({
      next: (games) => {
        this.favorites = games;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error al cargar la wishlist:', err);
        this.errorMessage =
          'No pudimos cargar tu lista de favoritos. Intentá de nuevo más tarde.';
        this.loading = false;
      },
    });
  }

  async removeFromWishlist(game: Game): Promise<void> {
    try {
      await this.wishlistService.removeGame(game);
      this.favorites = this.favorites.filter((g) => g.id !== game.id);
    } catch (err) {
      console.error('Error al eliminar de favoritos:', err);
      this.errorMessage = 'No se pudo eliminar el juego. Intentá de nuevo.';
    }
  }

  openGame(game: Game): void {
    window.open(game.game_url, '_blank', 'noopener');
  }
}
