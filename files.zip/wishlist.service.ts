import { Injectable, inject } from '@angular/core';
import {
  Firestore,
  doc,
  docData,
  setDoc,
  updateDoc,
  getDoc,
  arrayUnion,
  arrayRemove,
} from '@angular/fire/firestore';
import { Auth, authState } from '@angular/fire/auth';
import { Observable, of, switchMap, map, from, throwError } from 'rxjs';
import { Game } from '../models/game';

export interface WishlistDoc {
  id_user: string;
  userEmail: string;
  games: Game[];
}

/**
 * Servicio de wishlist / favoritos.
 * Estructura en Firestore: wishlists/{uid} -> { id_user, userEmail, games: Game[] }
 * Se usa el uid como identificador de documento (no el email), porque el email puede cambiar.
 * No se guarda ningún dato de contraseña: eso lo maneja Firebase Authentication.
 */
@Injectable({ providedIn: 'root' })
export class WishlistService {
  private firestore = inject(Firestore);
  private auth = inject(Auth);

  /**
   * Emite la wishlist completa (array de juegos) del usuario autenticado.
   * Si no hay usuario logueado, emite un array vacío en lugar de lanzar error,
   * para que los componentes puedan mostrar el estado "vacío" sin romperse.
   */
  getWishlist(): Observable<Game[]> {
    return authState(this.auth).pipe(
      switchMap((user) => {
        if (!user) {
          return of<Game[]>([]);
        }
        const ref = doc(this.firestore, `wishlists/${user.uid}`);
        return docData(ref).pipe(
          map((data) => (data as WishlistDoc | undefined)?.games ?? [])
        );
      })
    );
  }

  /**
   * Indica si un juego puntual ya está en favoritos.
   * Se deriva de getWishlist() para no duplicar lógica de lectura.
   */
  isInWishlist(gameId: string): Observable<boolean> {
    return this.getWishlist().pipe(
      map((games) => games.some((g) => g.id === gameId))
    );
  }

  /**
   * Agrega un juego a la wishlist del usuario autenticado.
   * Evita duplicados comprobando game.id antes de escribir.
   * Rechaza la operación si no hay usuario autenticado.
   */
  async addGame(game: Game): Promise<void> {
    const user = this.auth.currentUser;
    if (!user) {
      throw new Error('Debes iniciar sesión para agregar juegos a favoritos.');
    }

    const ref = doc(this.firestore, `wishlists/${user.uid}`);
    const snapshot = await getDoc(ref);

    if (!snapshot.exists()) {
      // Primer favorito del usuario: se crea el documento.
      const newDoc: WishlistDoc = {
        id_user: user.uid,
        userEmail: user.email ?? '',
        games: [game],
      };
      await setDoc(ref, newDoc);
      return;
    }

    const current = (snapshot.data() as WishlistDoc).games ?? [];
    const alreadyExists = current.some((g) => g.id === game.id);
    if (alreadyExists) {
      return; // Evita duplicados.
    }

    await updateDoc(ref, {
      games: arrayUnion(game),
    });
  }

  /**
   * Elimina un juego de la wishlist del usuario autenticado, por game.id.
   * Rechaza la operación si no hay usuario autenticado.
   */
  async removeGame(game: Game): Promise<void> {
    const user = this.auth.currentUser;
    if (!user) {
      throw new Error('Debes iniciar sesión para modificar tus favoritos.');
    }

    const ref = doc(this.firestore, `wishlists/${user.uid}`);
    const snapshot = await getDoc(ref);
    if (!snapshot.exists()) return;

    const current = (snapshot.data() as WishlistDoc).games ?? [];
    const target = current.find((g) => g.id === game.id);
    if (!target) return;

    // arrayRemove necesita el objeto exacto tal como está guardado,
    // así que se usa el que ya viene de Firestore en vez del parámetro recibido.
    await updateDoc(ref, {
      games: arrayRemove(target),
    });
  }
}
