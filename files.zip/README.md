# Implementación de favoritos/wishlist — gameCatalog

## Estructura de datos en Firestore

```
wishlists/{uid}
  ├─ id_user: string      (el uid de Firebase Auth)
  ├─ userEmail: string
  └─ games: Game[]        (array de juegos completos)
```

Un documento por usuario, indexado por `uid` (no por email, porque el email puede
cambiar). No se guarda ningún dato de contraseña.

## Pasos para integrarlo en tu proyecto real

1. **Copiar el servicio**
   Copiá `wishlist.service.ts` a `src/app/services/`. Reemplaza la lógica comentada
   de `user-service.ts` que usaba `localStorage` — no la reactives, usá este
   servicio nuevo en su lugar (podés renombrarlo o fusionarlo con `UserService`
   si preferís mantener un solo servicio, pero mantené los métodos separados).

2. **Actualizar `game-component.ts` y `game-component.html`**
   Tomá como referencia los archivos de esta carpeta. Ajustá los imports según
   las rutas reales de tu proyecto (`../../models/game`, etc.) y el diseño
   Tailwind existente si difiere del que usé acá.

3. **Actualizar `profile.ts`**
   Igual que el paso anterior: mantené `ProfileService` como está (edición de
   nombre/contraseña) y sumá la carga de favoritos con `WishlistService`.

4. **Reemplazar el bloque "Mi Lista" en `profile.html`**
   Usá `profile-mi-lista.html` como referencia para el bloque que reemplaza el
   texto estático "No hay juegos en tu lista".

5. **Publicar las reglas de Firestore**
   Copiá el contenido de `firestore.rules` a tu archivo de reglas real y
   desplegalo con `firebase deploy --only firestore:rules` (o pegalo directamente
   en la consola de Firebase → Firestore → Reglas).

6. **Habilitar Firestore si aún no está habilitado**
   Si tu proyecto de Firebase todavía no tiene Firestore activado (solo
   Authentication), andá a la consola de Firebase → Firestore Database → Crear
   base de datos, en modo producción.

7. **Verificar `app.config.ts`**
   Confirmá que `provideFirestore(() => getFirestore())` está en los providers
   junto con `provideAuth`. Si solo tenés Authentication configurado, agregá
   ese provider sin duplicar la inicialización de la app de Firebase.

## Cómo se evitan los duplicados

`addGame()` lee el documento actual y comprueba `game.id` antes de escribir. Si
el juego ya está, no hace nada. Al eliminar, se usa `arrayRemove` con el objeto
exacto tal como está guardado en Firestore (por eso se busca primero con
`.find()` en vez de pasar el parámetro recibido directamente).

## Cómo se protege la información por usuario

- Cada documento vive en `wishlists/{uid}`, y las reglas de Firestore solo
  permiten leer/escribir el propio documento (`request.auth.uid == userId`).
- El servicio usa `authState(auth)` para reaccionar automáticamente a
  login/logout: al cerrar sesión, `getWishlist()` empieza a emitir `[]`, así
  que no quedan datos del usuario anterior visibles en pantalla.
- Ninguna operación de escritura se ejecuta si `auth.currentUser` es `null`.

## Pendiente de tu lado

- Adaptar las rutas de import a la estructura real de tu proyecto.
- Correr `ng test` y `ng build` después de integrar los cambios.
- Revisar visualmente que el botón de favoritos no rompa el layout responsive
  de las tarjetas actuales.
